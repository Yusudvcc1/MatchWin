# MatchWin Frontend

This folder contains the Next.js frontend for the MatchWin betting platform.